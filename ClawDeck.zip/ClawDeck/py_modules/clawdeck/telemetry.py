"""Power readings for the performance overlay (Steam's, MangoHud).

The overlay runs as the desktop user and reads the chip's energy counters (RAPL `energy_uj`) to show CPU watts. Since
2020 Linux makes those counters root-only (mode 0400): sampling them fast enough can leak information about what
other programs compute (the "PLATYPUS" side channel). So on a stock Claw the overlay shows 0.0 W.

"Watts in the overlay" (Fixes) makes the package counters readable by everyone (0444) while it is on, reapplied by
ClawDeck at every start because sysfs resets at boot, and puts 0400 back when switched off. On the Claw 8 EX the
package domain covers CPU and graphics together. The xe driver has no GPU power sensor for an integrated GPU, so the
overlay reads the GPU's watts from the uncore sub-domain (the graphics part of Intel client chips; MangoHud from
flightlessmango/MangoHud#2211): that counter opens and closes with the package counters.

The battery's own reading is not touched here: on the Claw 8 EX the kernel reports current_now as about −64.6 A
(HARDWARE-FINDINGS §6); battery_watts() corrects it for ClawDeck's own read-back.
"""
from __future__ import annotations

import glob
import logging
import os

log = logging.getLogger("clawdeck.telemetry")

POWERCAP = "/sys/class/powercap"
# package domains, and the uncore sub-domain for the GPU's watts; core and dram are not what the overlay shows
DOMAINS = ("intel-rapl:0", "intel-rapl-mmio:0")
SUB_DOMAINS = ("uncore",)
OPEN, CLOSED = 0o444, 0o400


def sub_counters(root: str = POWERCAP) -> list[str]:
    """The sub-domain counters by name: their numbers (intel-rapl:0:N) differ between chips."""
    found = []
    for d in sorted(glob.glob(os.path.join(root, "intel-rapl:0:*"))):
        try:
            with open(os.path.join(d, "name"), encoding="utf-8") as f:
                name = f.read().strip()
        except OSError:
            continue
        if name in SUB_DOMAINS and os.path.exists(os.path.join(d, "energy_uj")):
            found.append(os.path.join(d, "energy_uj"))
    return found


def counters(root: str = POWERCAP) -> list[str]:
    return [p for d in DOMAINS for p in [os.path.join(root, d, "energy_uj")] if os.path.exists(p)] + sub_counters(root)


def status(root: str = POWERCAP) -> dict:
    files = []
    for p in counters(root):
        try:
            mode = os.stat(p).st_mode & 0o777
        except OSError:
            continue
        files.append({"path": p, "mode": oct(mode), "readable": bool(mode & 0o004)})
    return {"available": bool(files), "on": bool(files) and all(f["readable"] for f in files), "files": files}


TMPFILES = "/etc/tmpfiles.d/clawdeck-overlay-power.conf"


def boot_rule(on: bool, path: str = TMPFILES, root: str = POWERCAP) -> str | None:
    """The performance overlay (mangoapp) checks the counter once, when Game Mode starts: opened later, it keeps
    showing no watts until the next session. A systemd-tmpfiles rule opens the counters at boot, before Game Mode;
    removing the file undoes it. Returns an error text or None."""
    try:
        if on:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write("# ClawDeck: watts in the performance overlay (Fixes). Remove this file to undo.\n")
                for d in DOMAINS:
                    f.write(f"z {root}/{d}/energy_uj 0444 - - -\n")
                for p in sub_counters(root):
                    f.write(f"z {p} 0444 - - -\n")
        elif os.path.exists(path):
            os.remove(path)
    except OSError as e:
        return f"{path}: {e}"
    return None


def apply(on: bool, root: str = POWERCAP) -> dict:
    """Open (0444) or close (0400) the package energy counters. Returns what each one reads afterwards."""
    errors = []
    if root == POWERCAP:
        e = boot_rule(on)
        if e:
            errors.append(e)
    for p in counters(root):
        try:
            os.chmod(p, OPEN if on else CLOSED)
        except OSError as e:
            errors.append(f"{p}: {e.strerror or e}")
    st = status(root)
    if not st["available"]:
        return {"ok": False, "error": "no RAPL package energy counter on this kernel", **st}
    ok = not errors and st["on"] == on
    if errors:
        log.warning("overlay power counters: %s", "; ".join(errors))
    return {"ok": ok, "error": "; ".join(errors) or (None if ok else "the counters didn't change"), **st}


def battery_watts(bat: str | None = None, fix_16bit: bool = True) -> float | None:
    """Battery power in W (negative = discharging), from power_now or current_now x voltage_now. The Claw 8 EX's
    DSDT negates the EC's signed 16-bit current without masking the result to 16 bits: −934 mA becomes 0xffff03a6,
    which the kernel reports as −64 602 mA. Below −32 768 mA no battery is real, so the low 16 bits are taken back
    (+ 65 536 mA). Kernels with the ACPI battery fix (sent to linux-acpi 2026-11-14) report the right value."""
    bats = [bat] if bat else sorted(glob.glob("/sys/class/power_supply/BAT*"))
    for b in bats:
        def rd(name: str) -> int | None:
            try:
                with open(os.path.join(b, name), "r", encoding="utf-8") as f:
                    return int(f.read().strip())
            except (OSError, ValueError):
                return None
        p = rd("power_now")
        if p is not None:
            w = p / 1e6
        else:
            i, v = rd("current_now"), rd("voltage_now")
            if i is None or v is None:
                continue
            if fix_16bit and i < -32_768_000:
                i += 65_536_000
            w = i * v / 1e12
        st = None
        try:
            with open(os.path.join(b, "status"), "r", encoding="utf-8") as f:
                st = f.read().strip()
        except OSError:
            pass
        if st == "Discharging" and w > 0:
            w = -w
        return round(w, 1)
    return None


def external_display(drm: str = "/sys/class/drm") -> dict:
    """Is a display other than the Claw's own screen connected (DP/HDMI, a dock or USB-C monitor)? Then gamescope
    shows the picture there, and its VRR is the user's choice: ClawDeck's "VRR only in games" stands aside."""
    found = []
    for st in sorted(glob.glob(os.path.join(drm, "card*-*", "status"))):
        conn = os.path.basename(os.path.dirname(st)).split("-", 1)[1]
        if conn.startswith(("eDP", "LVDS", "DSI")) or conn.startswith("Writeback"):
            continue
        try:
            with open(st, "r", encoding="utf-8") as f:
                if f.read().strip() == "connected":
                    found.append(conn)
        except OSError:
            continue
    return {"connected": bool(found), "connectors": found}
